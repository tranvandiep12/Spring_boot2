package com.sqc.APIMayTinh;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiMayTinhApplicationTests {

	@Test
	void contextLoads() {
	}

}
