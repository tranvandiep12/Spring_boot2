package com.sqc.APIQuanLiThongTinNhanVien;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiQuanLiThongTinNhanVienApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApiQuanLiThongTinNhanVienApplication.class, args);
	}

}
