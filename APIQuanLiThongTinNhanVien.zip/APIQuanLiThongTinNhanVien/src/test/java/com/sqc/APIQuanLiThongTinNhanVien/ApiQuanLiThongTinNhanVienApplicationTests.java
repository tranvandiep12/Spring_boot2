package com.sqc.APIQuanLiThongTinNhanVien;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiQuanLiThongTinNhanVienApplicationTests {

	@Test
	void contextLoads() {
	}

}
