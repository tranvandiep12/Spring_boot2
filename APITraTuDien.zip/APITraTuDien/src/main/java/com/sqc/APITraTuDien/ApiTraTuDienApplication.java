package com.sqc.APITraTuDien;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiTraTuDienApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApiTraTuDienApplication.class, args);
	}

}
