package com.sqc.APITraTuDien;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiTraTuDienApplicationTests {

	@Test
	void contextLoads() {
	}

}
